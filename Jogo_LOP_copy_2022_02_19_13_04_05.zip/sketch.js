var tela = 1 //tela inicial
var largura = 200;
var altura = 50;
var xMenu = 150;
var yMenu1 = 200;
var yMenu2 = 145;
var yMenu3 = 255;
var img;
var resultado = ""
var questao = 0
var button
var telaAnterior
var musica

function preload() {
  img = loadImage("John.png");
  img2 = loadImage("Pensadores.jpg")
  img3 = loadImage("pensamento.png")
  musica = loadSound("audio.wav")
  }

function setup() {
  createCanvas(500, 400);
}

const questions = [
  {
    "question": 1,
    "title": "Questao 1 -Qual o significado da expressão grega Physis?",
     "alternatives": [
      {"option": "a", "text": "Natureza"},
      {"option": "b", "text": "Pensamento"},
      {"option": "c", "text": "Mitologia"},
       ],
    "correctAlternative": "a",
    "nextQuestion": 1
  },
  {
   "question": 2,
    "title": "Questao 2 - Qual era a arkhé para Anaxímenes?",
    "alternatives": [
      {"option": "a", "text": "A Água"},
      {"option": "b", "text": "O Fogo"},
      {"option": "c", "text": "O Ar"},
    ],
    "correctAlternative": "c",
    "nextQuestion": 2 
  },
   {
   "question": 3,
    "title": "Questao 3 - Qual o nome dado pelos \n primeiros filósofos ao princípio de tudo?",
    "alternatives": [
      {"option": "a", "text": "Physis"},
      {"option": "b", "text": "Arkhé"},
      {"option": "c", "text": "Mito"},
    ],
    "correctAlternative": "b",
    "nextQuestion": 3 
  },
  {
    "question": 4,
    "title": "Questao 4 - Qual o nome dado por Anaximandro ao infinito \n e indeterminado, do qual teriam surgido todas as coisas?",
    "alternatives": [
      {"option": "a", "text": "Arkhé"},
      {"option": "b", "text": "Ápeiron"},
      {"option": "c", "text": "Physis"},
    ],
    "correctAlternative": "b",
    "nextQuestion": null
  }
]

// Definição da questão inicial
var questionSelected = questions[0]

function draw() {
    
  
  function validaResposta(alternativaSelecionada, alternativaCorreta) {
    if(alternativaSelecionada == alternativaCorreta) {
      return "Verdadeiro"
    } else {
      return "Falsa"
    }
  }
  textStyle(NORMAL);
  background(100, 149, 237);
  image(img2,0,0,500,400)
  
  
if(tela==1)
{
  menu()
}
else
{

  if(tela==2)
  {
    fases()
  }
  else
    {
      if(tela==3)
      {
         informacoes()
      }
      else
        {
      if(tela==4)
        creditos()
      }
  
    }
}

function menu() {
  //Tela de Menu
  // Iniciar
  
  textSize(40)
  text ("Menu", 250, 70)
  textAlign(CENTER);
  textSize(26);
  if (
    mouseX > xMenu &&
    mouseX < xMenu + largura &&
    mouseY > yMenu2 &&
    mouseY < yMenu2 + altura
  ) {
    stroke(210, 105, 30);
    fill(255, 204, 41);
    rect(xMenu, yMenu2, largura, altura, 150);
    if(mouseIsPressed){
      setTimeout(() => {tela=2}, 1000);
  }
  }
  fill(240);
  noStroke();
  text("Iniciar", 250, 180);
  

  //Informações

  if (
    mouseX > xMenu &&
    mouseX < xMenu + largura &&
    mouseY > yMenu1 &&
    mouseY < yMenu1 + altura
  ) {
    stroke(210, 105, 30);
    fill(255, 204, 41);
    rect(xMenu, yMenu1, largura, altura, 150);
    if(mouseIsPressed){
    tela=3;
  }
  }

  fill(240);
  noStroke();
  text("Informações", 250, 233);
  

  //Créditos

  if (
    mouseX > xMenu &&
    mouseX < xMenu + largura &&
    mouseY > yMenu3 &&
    mouseY < yMenu3 + altura
  ) {
    stroke(210, 105, 30);
    fill(255, 204, 41);
    rect(xMenu, yMenu3, largura, altura, 150);
    if(mouseIsPressed){
    tela=4;
  }
  }

  fill(240);
  noStroke();
  text("Créditos", 250, 290);
}

function fases() {
  // Tela da Fase
  //tela = 2
  function playsound(){
  if(tela == telaAnterior){
    return false;
    }else{
    telaAnterior = tela; return true;
    }
}
  if(playsound()){
    musica.loop();
    outputVolume(0.3)
}
  
  image(img3,0,0,500,400)
  textSize(18);
  textAlign(CENTER)
  text(questionSelected.title, 250, 70);
  fill("");
  noStroke( );
 
  let alternativeHeight = 145
    questionSelected.alternatives.map(alternative => {
      showAlternative = alternative.option + ") " + alternative.text
      if(
        mouseX > xMenu &&
        mouseX < xMenu + largura &&
        mouseY > alternativeHeight &&
        mouseY < alternativeHeight + altura
      ) {
        stroke(210, 105, 30);
        fill(255, 204, 41);
        rect(xMenu, alternativeHeight, largura, altura, 150);
        
        if(mouseIsPressed && mouseButton === LEFT) {
          resultado = validaResposta(alternative.option, questionSelected.correctAlternative)
        }
      }
      textAlign(CENTER);
      textSize(26);
      fill("black") //cor das alternativas
      noStroke()
      text(showAlternative, 250, alternativeHeight + 35)
  
 alternativeHeight += 55 
})

  if(resultado == "Verdadeiro") {
      noLoop();
      setTimeout(() => {
        if(questionSelected.nextQuestion != null){
          resultado = ""
          questionSelected = questions[questionSelected.nextQuestion]
          clear()
          menu()
          loop()
        } else {
          tela = 4
          loop()
        }
      }, 1000)
    }
    
    textAlign(CENTER)
    textSize(26)
    if(resultado == "Verdadeiro") {
      fill("green")
    } else {
      fill("red")
    }
    noStroke()
    text(resultado, 250, 350)
  if (keyIsDown(ESCAPE)){tela=1}
  }
  
  
function informacoes() {
  // Tela de Informações
tela = 3
  background(100, 149, 237);
  textSize(40);
  text("Informações", 250, 80);
  fill(255,255,255);
  noStroke();
  textSize(18);
  text("Esse jogo visa identificar, analisar e comparar diferentes fontes e narrativas expressas em diversas linguagens, com vistas à compreensão de ideias filosóficas e de processos e eventos históricos, geográficos, políticos, econômicos, sociais, ambientais e culturais.", 50,150,400);
  text("Pressione a tecla ESC para voltar para o menu inicial", 50,340,400)
  if (keyIsDown(ESCAPE)){tela=1}
}

function creditos() {
  // Tela de Créditos
tela = 4
  textStyle(NORMAL);
  background(100, 149, 237);
  textSize(40);
  text("Créditos", 250, 80);
  image(img, 200, 100, 90, 90);
  textSize(20);
  text("John Watson Ferreira de Araújo - Educador e programador", 50, 200, 400);
  textSize(14);
  text(
    "Licenciado em Filosofia e Especialista em Ensino de Filosofia pela Universidade Federal do Rio Grande do Norte, Professor de Filosofia no Centro Educacional Santo Agostinho e no Centro Educacional Teresa de Lisieux",50,270,400);
  if (keyIsDown(ESCAPE)){tela=1}
  
}
}

//https://youtu.be/mBZiVhQDJCY - Video avaliação 1
//https://youtu.be/yjARHEjZ6RI - Vídeo avaliação 2